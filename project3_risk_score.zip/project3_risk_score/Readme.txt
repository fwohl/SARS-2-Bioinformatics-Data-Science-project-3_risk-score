####################
####################
###04.10.2024
####Friederike Wohlfarth
####this is the readme for the files for Project 3 of the Practical course: SARS-2 Bioinformatics & Data Science, winter term 24/25, @free University berlin
###the project task is on GitHub:
###https://github.com/rki-mf1/2024-SC2-Data-Science/blob/main/projects/project03.md
####
#how to work with the files
#for aligning, variant calling and statistics use Project.sh script on bash that produces the files in this folder
#you will need a conda environment 
#the script produces almost all the files in the project folder
#for the machine learning part and the visualization (barplots and Boxplots), use the R script
#you will Need additional files which are in the project Folder
#the code is on GitHub: https://github.com/fwohl/SARS-2-Bioinformatics-Data-Science-project-3_risk-score